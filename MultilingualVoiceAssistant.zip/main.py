import whisper
import sounddevice as sd
from scipy.io.wavfile import write
import pyttsx3
import os
import time

# Record Audio
def record_audio(filename='input.wav', duration=5, fs=44100):
    print("Speak now...")
    recording = sd.rec(int(duration * fs), samplerate=fs, channels=1)
    sd.wait()
    write(filename, fs, recording)
    print("Audio recorded and saved as", filename)

# Transcribe using Whisper
def transcribe_audio(filename='input.wav'):
    model = whisper.load_model("base")
    result = model.transcribe(filename)
    print("You said:", result['text'])
    return result['text']

# Text to Speech
def speak_text(text):
    engine = pyttsx3.init()
    engine.setProperty('rate', 150)
    engine.setProperty('volume', 1.0)
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)  # female
    engine.say(text)
    engine.runAndWait()

# Main
record_audio()
user_input = transcribe_audio()
speak_text("You said " + user_input)
